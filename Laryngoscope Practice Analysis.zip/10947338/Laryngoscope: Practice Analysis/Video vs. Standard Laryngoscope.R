install.packages("medicaldata")
library(medicaldata)
data(package = "medicaldata")

data("laryngoscope")
View(laryngoscope)
t_laryngoscope <- as_tibble(laryngoscope)
View(t_laryngoscope)

t_laryngoscope$gender <- factor(t_laryngoscope$gender, levels = c(1, 0), labels = c("Male", "Female"))
t_laryngoscope$asa <- as.factor(t_laryngoscope$asa)
t_laryngoscope$Mallampati <- as.factor(t_laryngoscope$Mallampati)
t_laryngoscope$Randomization <- factor(t_laryngoscope$Randomization, levels = c(1, 0), labels = c("Video", "Standard"))
t_laryngoscope$attempts <- as.factor(t_laryngoscope$attempts)
t_laryngoscope$failures <- as.factor(t_laryngoscope$failures)
t_laryngoscope$intubation_overall_S_F <- factor(t_laryngoscope$intubation_overall_S_F, levels = c(1, 0), labels = c("yes", "no"))
t_laryngoscope$bleeding <- factor(t_laryngoscope$bleeding, levels = c(1, 0), labels = c("yes", "no"))
t_laryngoscope$sore_throat <- factor(t_laryngoscope$sore_throat, levels = c(3, 2, 1, 0), labels = c("severe", "moderate", "mild", "none"))

colnames(t_laryngoscope)

ggplot(data = t_laryngoscope) +
  geom_bar(mapping = aes(x = Mallampati, fill = attempts)) +
  labs(title="Predicted Ease by attempt")

ggplot(data = t_laryngoscope) +
  geom_point(mapping = aes(x = ease, y = total_intubation_time, colour = attempts)) +
  labs(title="Ease, Time of Intubation")

ggplot(data = t_laryngoscope) +
  geom_bar(mapping = aes(x = attempts, fill = bleeding )) +
  facet_wrap(~ view) +
  labs(title="Occurence of Bleeding")

ggplot(data = t_laryngoscope) +
  geom_bar(mapping = aes(x = Randomization, fill = intubation_overall_S_F)) +
  facet_wrap(~ attempts) +
  theme(axis.text.x = element_text(angle = 45)) +
  labs(title="Successful Itubation, Method and Attempts")

ggplot(data = t_laryngoscope) +
  geom_point(mapping = aes(x = Randomization, y = BMI, color =Randomization)) +
  facet_wrap(~ attempts) +
  theme(axis.text.x = element_text(angle = 45)) +
  labs(title="Successful Itubation, Method and BMI")